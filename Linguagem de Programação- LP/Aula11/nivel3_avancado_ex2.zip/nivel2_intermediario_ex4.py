import pyautogui
import time

time.sleep(3)
pyautogui.scroll(-1000)
time.sleep(1)
pyautogui.scroll(1000)