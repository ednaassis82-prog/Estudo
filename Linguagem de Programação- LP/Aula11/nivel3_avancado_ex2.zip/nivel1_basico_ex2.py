import pyautogui
import time
pyautogui.moveTo(100,100,duration=1)
pyautogui.moveTo(500,300,duration=1)
pyautogui.moveTo(900,500,duration=1)
time.sleep(1)
print("Movimentos concluídos")