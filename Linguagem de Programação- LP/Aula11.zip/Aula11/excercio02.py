import pyautogui
import time


pyautogui.PAUSE = 0.7
pyautogui.press("win")
pyautogui.write("chrome")
pyautogui.press("enter")
pyautogui.write("wikipedia.org")
pyautogui.press("enter")






