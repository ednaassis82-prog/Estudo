def soma (a,b) :
    s= a+b
    print(soma)
    soma(7,9)

  




