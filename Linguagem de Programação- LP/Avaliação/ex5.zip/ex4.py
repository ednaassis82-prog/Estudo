with open("alunos.txt", "w")as arquivo:
    arquivo.write("Aline. \n")

with open("alunos.txt", "w")as arquivo:
    arquivo.write("Erica. \n")

with open("alunos.txt", "w")as arquivo:
    arquivo.write("Rael. \n")