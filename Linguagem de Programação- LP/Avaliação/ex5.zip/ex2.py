def saudacao(nome= "Edna"):
    print(f"Boa noite, {nome}")

    saudacao ("Edna")