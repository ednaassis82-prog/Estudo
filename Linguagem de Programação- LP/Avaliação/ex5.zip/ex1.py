num1=int(input("digite o primeiro número:" ))

num2=int(input("digite o segundo número:" ))

if num1 > num2:
        print("o primeiro numero é maior que o segundo número")
elif num2 > num1:
        print("o primeiro é menor que o segundo número ")
else:
        print("o dois números são iguais ")











    






















    